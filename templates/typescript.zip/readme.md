# Fullstack System Boilerplate
Run `npm start` or `fullstack-system dev` to start the development server.
