import React, { useState } from 'react';
import { hot } from 'react-hot-loader/root';
import useSocket from '@fullstack-system/useSocket';

function App() {
  const [value, setValue] = useState(0);

  const socket = useSocket((socket) => {
    // Bind Events Here
    socket.on('value', (value) => {
      setValue(value);
    });
  }, []);

  // Event Handlers
  const handleButtonPress = () => {
    socket.emit('click');
  };

  return <div>
    <h1>Hello World!</h1>
    <p>
      This counter is global to all users that visit this page, it gets reset when you restart the server.
    </p>
    <p>
      Value: <b>{value}</b>
    </p>
    <button onClick={handleButtonPress}>Send Click</button>
  </div>;
}

export default hot(App);
