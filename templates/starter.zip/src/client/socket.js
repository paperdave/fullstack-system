import { connect } from 'fullstack-system';

export default connect();
